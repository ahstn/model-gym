"""Audit all Lite receipts and unchanged delivered requests before cloud shutdown."""
import base64
import json
import math
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

EXPERIMENT = Path('/tmp/model-gym-rehearsal-20261101/visual-quality/experiments/rehearsal-4000-2026-11-01')
DATA = Path('/home/ahstn/git/model-gym/visual-quality/data/rehearsal-4000-2026-11-01')
DIRECTORY = DATA / 'results/lite/all'
sys.path.insert(0, str(EXPERIMENT))
import lite_runner as lite


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


summary = read(DIRECTORY / 'summary.json')
require(summary['status'] == 'complete', 'Run is incomplete')
manifest_bytes = (EXPERIMENT / 'manifest.json').read_bytes()
cases = json.loads(manifest_bytes)['cases']
require(len(cases) == 4000, 'Need the full 4000-case manifest')
by_id = {case['case_id']: case for case in cases}
run = read(DIRECTORY / 'run.json')
config = run['configuration']
require(config['manifest_sha256'] == lite.digest_bytes(manifest_bytes), 'Changed manifest')
require(config['client_sha256'] == lite.digest_bytes(Path(lite.__file__).read_bytes()), 'Changed client')
require(config['case_ids'] == [case['case_id'] for case in lite.select_cases(cases, 'all')], 'Changed case order')
require(config['model'] == lite.MODEL and config['revision'] == lite.REVISION, 'Changed checkpoint')
require(run['run_id'] == lite.digest_bytes(lite.canonical(config)), 'Changed run configuration')
require(config['reference_admission'] == lite.reference_admission(cases, EXPERIMENT / 'references-freeze.json', EXPERIMENT / 'manifest.json'), 'Changed benchmark admission')
identity = read(DIRECTORY / 'server-identity.json')
require(config['server_identity_sha256'] == lite.digest_bytes(lite.canonical(identity)), 'Changed server identity')
paths = sorted((DIRECTORY / 'attempts').glob('*.json'))
require(len(paths) == 4000 and {path.stem for path in paths} == set(by_id), 'Wrong attempt coverage')
rows, hashes = [], []
for number, path in enumerate(paths, 1):
    row = read(path)
    case = by_id[path.stem]
    require(row['status'] in ('valid', 'partial', 'invalid'), 'Unresolved request')
    require(row['run_id'] == run['run_id'] and row['case_id'] == case['case_id'], 'Wrong request identity')
    require(row['family_id'] == case['family_id'] and row['view_sha256'] == case['view_sha256'], 'Wrong image lineage')
    require(row['benchmark_partition'] == case['benchmark_partition'], 'Wrong partition')
    require(row['checkpoint'] == lite.MODEL and row['revision'] == lite.REVISION, 'Wrong row checkpoint')
    require(row['price_usd'] == '0.00', 'Price override changed')
    require(math.isfinite(row['latency_seconds']) and row['latency_seconds'] >= 0, 'Invalid measured latency')
    image = Path(case['image_path']).read_bytes()
    require(lite.digest_bytes(image) == case['view_sha256'], 'Delivered view changed')
    payload = lite.canonical({'image': base64.b64encode(image).decode('ascii')})
    require(lite.digest_bytes(payload) == row['request_sha256'] and len(payload) == row['request_bytes'], 'Request payload changed')
    expected_attempt = lite.digest_bytes(lite.canonical([run['run_id'], case['case_id'], case['view_sha256']]))
    require(expected_attempt == row['attempt_id'], 'Wrong attempt ID')
    raw_path = Path(row['raw_response_path'])
    require(raw_path == DIRECTORY / 'raw' / (expected_attempt + '.json'), 'Wrong raw evidence location')
    raw = read(raw_path)
    require(raw['status'] == 200 and row['http_status'] == 200, 'Non-success response')
    response = json.loads(raw['body'])
    normalized = lite.normalize_response(response)
    require(all(row.get(key) == value for key, value in normalized.items()), 'Stored score differs from raw response')
    require(row['server_processing_seconds'] == response['seconds'], 'Server timing differs from raw response')
    require(row['peak_vram_bytes'] == response['peak_vram'], 'VRAM differs from raw response')
    hashes.append({'case_id': case['case_id'], 'attempt_sha256': lite.digest_bytes(path.read_bytes()), 'raw_response_sha256': lite.digest_bytes(raw_path.read_bytes())})
    rows.append(row)
    if number % 1000 == 0:
        print(json.dumps({'verified': number, 'total': 4000}), flush=True)

require(summary['completed_cases'] == len(rows), 'Summary coverage mismatch')
require(summary['valid_cases'] == sum(row['status'] == 'valid' for row in rows), 'Summary valid count mismatch')
start = min(datetime.fromisoformat(row['request_started_at']) for row in rows)
end = max(datetime.fromisoformat(row['response_received_at']) for row in rows)
evidence = {
    'verified_at': datetime.now(timezone.utc).isoformat(), 'status': 'passed',
    'cases': len(rows), 'statuses': dict(Counter(row['status'] for row in rows)),
    'partitions': dict(Counter(row['benchmark_partition'] for row in rows)),
    'run_id': run['run_id'], 'run_configuration_sha256': lite.digest_bytes((DIRECTORY / 'run.json').read_bytes()),
    'verifier_sha256': lite.digest_bytes(Path(__file__).read_bytes()),
    'first_request_at': start.isoformat(), 'last_response_at': end.isoformat(),
    'request_window_seconds': (end - start).total_seconds(),
    'latency_seconds': {'median': statistics.median(row['latency_seconds'] for row in rows), 'mean': statistics.mean(row['latency_seconds'] for row in rows), 'minimum': min(row['latency_seconds'] for row in rows), 'maximum': max(row['latency_seconds'] for row in rows)},
    'server_processing_seconds': {'median': statistics.median(row['server_processing_seconds'] for row in rows), 'mean': statistics.mean(row['server_processing_seconds'] for row in rows)},
    'peak_vram_bytes': max(row['peak_vram_bytes'] for row in rows),
    'reported_price_usd': '0.00', 'price_basis': 'user_assigned_zero; cloud infrastructure accounted separately',
    'checks': ['all4000caseidentities', 'complete500referenceadmission', 'immutableclientandmanifest', 'deliveredviewSHA256', 'exactrequestpayloadSHA256andlength', 'immutableattemptIDs', 'allrawHTTPresponsesretrieved', 'independentrawresponsevalidation', 'measuredlatency', 'nativeprobabilitiesandscalemapping', 'noautomaticretries'],
    'receipt_hashes': hashes,
}
output = EXPERIMENT / 'lite-completion-validation.json'
with output.open('x') as handle:
    handle.write(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({key: value for key, value in evidence.items() if key != 'receipt_hashes'}, indent=2), flush=True)
